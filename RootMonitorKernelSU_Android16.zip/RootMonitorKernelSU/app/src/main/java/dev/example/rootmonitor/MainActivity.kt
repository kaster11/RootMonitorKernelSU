package dev.example.rootmonitor

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.content.pm.ApplicationInfo
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import java.io.File
import java.util.Locale
import kotlin.math.max

data class ProcRow(
    val pid: Int,
    val uid: Int,
    val packageName: String,
    val label: String,
    val rssKb: Long,
    val cpuPercent: Double,
    val rxBytes: Long?,
    val txBytes: Long?
)

class MainActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var status: TextView
    private lateinit var list: LinearLayout
    private lateinit var scroll: ScrollView
    private var previousCpu = mutableMapOf<Int, Pair<Long, Long>>() // pid -> (ticks, wall time)
    private var previousUidNet = mutableMapOf<Int, Pair<Long, Long>>()
    private var firewallBlocked = mutableSetOf<Int>()
    private var rootOk = false
    private val refreshMs = 2000L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(18, 22, 30)
        window.navigationBarColor = Color.rgb(18, 22, 30)
        buildUi()
        Thread {
            val result = Root.exec("id")
            rootOk = result.first == 0 && result.second.contains("uid=0")
            runOnUiThread {
                status.text = if (rootOk) "Root فعال است • KernelSU / su" else
                    "Root در دسترس نیست؛ مجوز su را در KernelSU تأیید کنید."
            }
            refresh()
        }.start()
    }

    private fun buildUi() {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 20, 20, 12)
            setBackgroundColor(Color.rgb(18, 22, 30))
        }
        val title = TextView(this).apply {
            text = "ROOT MONITOR"
            textSize = 22f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER_VERTICAL
        }
        status = TextView(this).apply {
            text = "در حال بررسی دسترسی Root..."
            textSize = 13f
            setTextColor(Color.rgb(150, 190, 255))
            setPadding(0, 8, 0, 12)
        }
        val refreshButton = Button(this).apply {
            text = "به‌روزرسانی"
            setOnClickListener { refresh() }
        }
        scroll = ScrollView(this)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        outer.addView(title)
        outer.addView(status)
        outer.addView(refreshButton)
        outer.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(outer)
    }

    private fun refresh() {
        Thread {
            val rows = collectProcesses()
            runOnUiThread {
                list.removeAllViews()
                if (rows.isEmpty()) {
                    addText("پردازشی خوانده نشد. دسترسی Root و سازگاری /proc را بررسی کنید.", 14, Color.WHITE)
                }
                rows.sortedByDescending { it.cpuPercent }.forEach { addProcessCard(it) }
            }
            handler.postDelayed({ refresh() }, refreshMs)
        }.start()
    }

    private fun collectProcesses(): List<ProcRow> {
        val rows = mutableListOf<ProcRow>()
        val pm = packageManager
        val appCache = mutableMapOf<Int, Pair<String, String>>()
        val now = System.currentTimeMillis()
        val cores = max(1, Runtime.getRuntime().availableProcessors())
        val procDirs = File("/proc").listFiles() ?: return emptyList()

        for (dir in procDirs) {
            val pid = dir.name.toIntOrNull() ?: continue
            try {
                val statusText = File(dir, "status").readText()
                val uid = Regex("(?m)^Uid:\\s+(\\d+)").find(statusText)?.groupValues?.get(1)?.toInt() ?: continue
                val rssKb = Regex("(?m)^VmRSS:\\s+(\\d+)").find(statusText)?.groupValues?.get(1)?.toLong() ?: 0L
                val stat = File(dir, "stat").readText()
                val close = stat.lastIndexOf(')')
                if (close < 0) continue
                val fields = stat.substring(close + 2).trim().split(Regex("\\s+"))
                // fields[0]=state; utime=field 11, stime=field 12 in proc stat (indices after comm)
                val ticks = fields.getOrNull(11)?.toLongOrNull()?.plus(fields.getOrNull(12)?.toLongOrNull() ?: 0L) ?: 0L
                val old = previousCpu[pid]
                val elapsed = old?.let { max(1L, now - it.second) } ?: 1L
                val delta = old?.let { max(0L, ticks - it.first) } ?: 0L
                val cpu = if (old == null) 0.0 else (delta * 1000.0 / elapsed / cores).coerceIn(0.0, 100.0)
                previousCpu[pid] = ticks to now

                val pkgInfo = appCache.getOrPut(uid) {
                    val packages = try { pm.getPackagesForUid(uid) } catch (_: Exception) { null }
                    val pkg = packages?.firstOrNull()
                    val label = try {
                        if (pkg != null) pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
                        else "UID $uid"
                    } catch (_: Exception) { pkg ?: "UID $uid" }
                    (pkg ?: "uid.$uid") to label
                }
                val net = readUidNetwork(uid)
                rows.add(ProcRow(pid, uid, pkgInfo.first, pkgInfo.second, rssKb, cpu, net?.first, net?.second))
            } catch (_: Exception) {
                // Process can disappear while being sampled.
            }
        }
        return rows
    }

    private fun readUidNetwork(uid: Int): Pair<Long, Long>? {
        // Legacy kernel accounting file; not present on all Android 16 kernels.
        val file = File("/proc/net/xt_qtaguid/stats")
        if (!file.canRead()) return null
        var rx = 0L
        var tx = 0L
        var found = false
        try {
            file.forEachLine { line ->
                val f = line.trim().split(Regex("\\s+"))
                if (f.size >= 9 && f[3].toIntOrNull() == uid) {
                    rx += f[5].toLongOrNull() ?: 0L
                    tx += f[7].toLongOrNull() ?: 0L
                    found = true
                }
            }
        } catch (_: Exception) { return null }
        return if (found) rx to tx else null
    }

    private fun addProcessCard(p: ProcRow) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 12, 14, 12)
            setBackgroundColor(Color.rgb(31, 38, 50))
        }
        val heading = TextView(this).apply {
            text = "${p.label}  •  PID ${p.pid}"
            textSize = 16f
            setTextColor(Color.WHITE)
        }
        val details = TextView(this).apply {
            val netText = if (p.rxBytes != null && p.txBytes != null)
                "شبکه UID: دریافت ${humanBytes(p.rxBytes)} / ارسال ${humanBytes(p.txBytes)}"
            else "شبکه UID: در هسته فعلی در دسترس نیست"
            text = "${p.packageName} • UID ${p.uid}\nRAM: ${p.rssKb / 1024} MB • CPU: ${String.format(Locale.US, "%.1f", p.cpuPercent)}%\n$netText"
            textSize = 12f
            setTextColor(Color.rgb(210, 218, 230))
            setPadding(0, 6, 0, 8)
        }
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val kill = Button(this).apply {
            text = "Kill PID"
            setOnClickListener {
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("خاتمه پردازش")
                    .setMessage("پردازش ${p.pid} خاتمه داده شود؟ برنامه یا سرویس سیستمی ممکن است ناپایدار شود.")
                    .setNegativeButton("لغو", null)
                    .setPositiveButton("Kill") { _, _ ->
                        Thread {
                            val res = Root.exec("kill -TERM ${p.pid}; sleep 1; if [ -r /proc/${p.pid}/stat ]; then kill -KILL ${p.pid}; fi")
                            runOnUiThread {
                                Toast.makeText(this@MainActivity, if (res.first == 0) "دستور ارسال شد" else "خطا: ${res.second}", Toast.LENGTH_LONG).show()
                            }
                        }.start()
                    }.show()
            }
        }
        val block = Button(this).apply {
            text = if (firewallBlocked.contains(p.uid)) "رفع قطع اینترنت" else "قطع اینترنت UID"
            setOnClickListener { toggleFirewall(p.uid) }
        }
        actions.addView(kill, LinearLayout.LayoutParams(0, -2, 1f))
        actions.addView(block, LinearLayout.LayoutParams(0, -2, 1f))
        card.addView(heading); card.addView(details); card.addView(actions)
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.bottomMargin = 10
        list.addView(card, lp)
    }

    private fun toggleFirewall(uid: Int) {
        if (uid < 0 || uid == android.os.Process.myUid()) {
            Toast.makeText(this, "UID نامعتبر یا متعلق به خود برنامه است.", Toast.LENGTH_LONG).show()
            return
        }
        val blocking = !firewallBlocked.contains(uid)
        // Dedicated chains make rules easier to identify/remove. Android may use nftables
        // or lack iptables binaries; command results are surfaced to the user.
        val v4 = if (blocking)
            "iptables -I OUTPUT 1 -m owner --uid-owner $uid -j REJECT"
        else
            "iptables -D OUTPUT -m owner --uid-owner $uid -j REJECT"
        val v6 = if (blocking)
            "ip6tables -I OUTPUT 1 -m owner --uid-owner $uid -j REJECT"
        else
            "ip6tables -D OUTPUT -m owner --uid-owner $uid -j REJECT"
        Thread {
            val r4 = Root.exec(v4)
            val r6 = Root.exec(v6)
            runOnUiThread {
                if (r4.first == 0 || r6.first == 0) {
                    if (blocking) firewallBlocked.add(uid) else firewallBlocked.remove(uid)
                    Toast.makeText(this, if (blocking) "قانون فایروال اعمال شد (ممکن است یکی از پروتکل‌ها ناموفق باشد)." else "درخواست رفع قانون ارسال شد.", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(this, "فایروال اعمال نشد. ابزار iptables یا پشتیبانی هسته موجود نیست.\n${r4.second}\n${r6.second}", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun addText(text: String, size: Int, color: Int) {
        list.addView(TextView(this).apply { this.text = text; textSize = size.toFloat(); setTextColor(color); setPadding(0, 12, 0, 12) })
    }

    private fun humanBytes(value: Long): String {
        if (value < 1024) return "$value B"
        if (value < 1024 * 1024) return String.format(Locale.US, "%.1f KB", value / 1024.0)
        return String.format(Locale.US, "%.1f MB", value / (1024.0 * 1024.0))
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}

object Root {
    fun exec(command: String): Pair<Int, String> {
        return try {
            val process = Runtime.getRuntime().exec(arrayOf("su", "-c", command))
            val out = process.inputStream.bufferedReader().readText()
            val err = process.errorStream.bufferedReader().readText()
            val code = process.waitFor()
            code to (if (out.isNotBlank()) out else err)
        } catch (e: Exception) {
            -1 to (e.message ?: "Unknown error")
        }
    }
}
