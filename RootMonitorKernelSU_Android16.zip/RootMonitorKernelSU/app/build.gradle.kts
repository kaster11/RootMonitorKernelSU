plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "dev.example.rootmonitor"
    compileSdk = 36
    defaultConfig {
        applicationId = "dev.example.rootmonitor"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
